import React from "react";

const productImages = {
  1: "/images/product1.jpg",
  2: "/images/product2.jpg",
  3: "/images/product3.jpg",
  4: "/images/product4.jpg",
  5: "/images/product5.jpg",
  6: "/images/product6.jpg",
  7: "/images/product7.jpg",
  8: "/images/product8.jpg",
  9: "/images/product9.jpg",
  10: "/images/product10.jpg",
  11: "/images/product11.jpg",
  12: "/images/product12.jpg",
  13: "/images/product13.jpg",
};

export default function App() {
  const products = Array.from({ length: 13 }, (_, i) => ({
    id: i + 1,
    name: `Product ${i + 1}`,
    price: "ضع السعر هنا",
    description: "وصف المنتج هنا",
  }));

  return (
    <div style={{ padding: 20 }}>
      <h1>ULTUMITE</h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20 }}>
        {products.map((product) => (
          <div key={product.id} style={{ border: "1px solid #ddd", padding: 10 }}>
            <img src={productImages[product.id]} alt="" style={{ width: "100%", height: 150, objectFit: "cover" }} />
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <p>{product.price}</p>
            <button>Buy Now</button>
          </div>
        ))}
      </div>
    </div>
  );
}
